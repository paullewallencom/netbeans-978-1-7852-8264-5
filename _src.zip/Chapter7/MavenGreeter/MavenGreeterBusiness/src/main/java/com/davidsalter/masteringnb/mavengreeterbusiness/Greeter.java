/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.davidsalter.masteringnb.mavengreeterbusiness;

/**
 *
 * @author david
 */
public class Greeter {
    
    public Greeter() {
    }

    public String greet(String name) {
        return "Hi " + name;
    }
}
