package com.davidsalter.masteringnb.springweb;

public class CustomerBean {
    // Nothing to see here.  This is an empty class to illustrate the 
    // Declare Spring Bean keyboard shortcut.
}
